#ifndef BITMAP_CPP
#define BITMAP_CPP
#include "BitMap.hpp"
#include "Helper.cpp"
#include <iostream>
#include <cstring>
#define MASKSZ 32
#define MAPSZ 32

BitMap::BitMap()
{
    helper::custom_memset<int>(map, 0, sizeof(map)/sizeof(int));
    int j;
    int setbmask = 0b00000000000000000000000000000001;
    for(j= MASKSZ-1; j>=0; j--)
    {
        mask[j] = mask[j] & setbmask;
        setbmask = setbmask << 1;
    }

}
BitMap::~BitMap(){}

void BitMap::clear_bitmap()
{
    //helper::custom_memset<int>(map, 0, sizeof(map)/sizeof(int));
    int i;
    for(i=0; i< MAPSZ; i++)
    {
        map[i] = 0;
    }
}
int* BitMap::get_bitmap()
{
    return map;
}
void BitMap::set_bit(int i)
{
    map[i/MAPSZ] = map[i/MAPSZ] | mask[i%MASKSZ];
}
void BitMap::clr_bit(int i)
{
    int tempmask[MASKSZ];
    int j;
    for(j=0; j<MASKSZ; j++)
    {
        tempmask[j] = ~mask[j];
    }
    map[i/MAPSZ] = map[i/MAPSZ] & tempmask[i%MASKSZ];    

}
int BitMap::get_first_unallocated_bit()
{
    int i,j, temp;
    for(i=0; i<MAPSZ; i++)
    {
        for(j=0; j<MASKSZ; j++)
        {
            temp = map[i] & mask[j];
            if(!temp)
            {
                return i*MAPSZ + j;
            }
        }
    }
    return 1;
}
int BitMap::get_first_unallocated_pair()
{
    int i;
    int total = MAPSZ*MASKSZ-1;
    for(i=0; i< total; i++)
    {
        if(!get_index(i) && !get_index(i+1))
        {
            return i;
        }
    }
    return -1;

}
int BitMap::get_index(int i)
{
    int temp = i;
    int j,k;
    for(j=0; j<MAPSZ; j++)
    {
        for(k=0; k<MASKSZ; k++)
        {
            temp = map[j] & mask[k];
            if(!i)
            {
                return temp;
            }
            i--;
        }
    }
    return -1;
}
#endif /* BITMAP_CPP */